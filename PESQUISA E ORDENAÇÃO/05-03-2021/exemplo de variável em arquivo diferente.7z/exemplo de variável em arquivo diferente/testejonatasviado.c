#include "testejonatasviado.h"
#include <stdio.h>

int main(){
printf("a variavel com o numero %i esta em outro arquivo chamado testejonatasviado.h\n no mesmo diretorio\n",a); //essa vari�vel est� em outro arquivo chamado jonatasviado.h
system("pause");
}
